import java.awt.Font;
import java.awt.event.*;  
import javax.swing.*;  
public class Function_Format 
{
    GUI gui;
    Font arial,comic,times,calibri,architect,antique,cursive,impact;
    String selectedFont;
    public Function_Format(GUI gui)
    {
        this.gui=gui;
    }
    
    public void wordWrap()
    {
        if(gui.wordWrapOn==false)
        {
            gui.wordWrapOn=true;
            gui.textArea.setLineWrap(true);
            gui.textArea.setWrapStyleWord(true);
            gui.iWrap.setText("Word Wrap: On");
        }
        else if(gui.wordWrapOn==true)
        {
            gui.wordWrapOn=false;
            gui.textArea.setLineWrap(false);
            gui.textArea.setWrapStyleWord(false);
            gui.iWrap.setText("Word Wrap: Off");
        }
    }

    public void createFont(int fontSize)
    {
        arial= new Font("Arial",Font.PLAIN,fontSize);
        comic= new Font("Comic Sans MS",Font.PLAIN,fontSize);
        times= new Font("Times New Roman",Font.PLAIN,fontSize);
        calibri= new Font("Calibri",Font.PLAIN,fontSize);
        architect= new Font("Architect",Font.PLAIN,fontSize);
        antique= new Font("Antiqua",Font.PLAIN,fontSize);
        cursive= new Font("Cursive",Font.PLAIN,fontSize);
        impact= new Font("Impact",Font.PLAIN,fontSize);
        

        setFont(selectedFont);
       
    }

    public void setFont(String font)
    {
        selectedFont=font;
        switch(selectedFont)
        {
            case "Arial": gui.textArea.setFont(arial); break;
            case "Comic Sans MS": gui.textArea.setFont(comic); break;
            case "Times New Roman": gui.textArea.setFont(times); break;
            case "Calibri": gui.textArea.setFont(calibri); break;
            case "Architect": gui.textArea.setFont(architect); break;
            case "Antiqua": gui.textArea.setFont(antique); break;
            case "Cursive": gui.textArea.setFont(cursive); break;
            case "Impact": gui.textArea.setFont(impact); break;    

        }
    }
    public void wordcount()
    {
      String text=gui.textArea.getText();  
    //if(e.getSource()==iwcount){  
        String words[]=text.split("\\s");  
        JOptionPane.showMessageDialog(gui.window,"Total words: "+words.length);  
     
    }
    public void charcount()
    {
        String text = gui.textArea.getText();
       // if(e.getSource()==iccount){  
        JOptionPane.showMessageDialog(gui.window,"Total Characters with space: "+text.length());  
        
    }
}